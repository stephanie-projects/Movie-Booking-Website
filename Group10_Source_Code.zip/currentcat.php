<?php
session_start();
?>
<html>
  <head>
    <title>Current Films</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center>
  <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Log Out</button>
  <button class="btn_right"
  onclick= "window.location.href='homepage.php';">Homepage</button>
</div>
</div>
<?php
  if($_SESSION["admin"] == "loggedin"){
    print_r("Welcome admin, Let's begin<br>");
  //echo "<button onClick='start()'>Start</button>";
  //show_hide() function is triggered on button click 
    echo "<button onClick='selectremove()'>Remove Films</button>";
    echo "<button onClick='add()'>Add Films</button>";   
  }
?>
  <script>
  function selectremove() {
  var x = document.getElementById("choice");
  var y = document.getElementById("myList");
  var z = document.getElementById("upcoming");
  var a = document.getElementById("choice2");
  var b = document.getElementById("sub1");
  if (x.style.display == 'none') {
    x.style.display = "block";
    y.style.display = "block";
    z.style.display = "block";
    a.style.display = "block";
    b.style.display = "block";
  }
  
}
  </script>
  
<script>
  function add() {
  var x = document.getElementById("addchoice");
  var y = document.getElementById("addchoicetext");
  var z = document.getElementById("addchoice2");
  var a = document.getElementById("addchoicetext2");
  var b = document.getElementById("addchoice3");
  var c = document.getElementById("addchoicetext3");
  var d = document.getElementById("sub2");
  if (x.style.display == 'none') {
    x.style.display = "block";
    y.style.display = "block";
    z.style.display = "block";
    a.style.display = "block";
    b.style.display = "block";
    c.style.display = "block";
    d.style.display = "block";
  }
  }
</script>
<script>
  function addmovie() {
    var filmname = document.getElementById("addchoicetext").value;
    var time = document.getElementById("addchoicetext2").value;
    var description = document.getElementById("addchoicetext3").value;
    const newDiv = document.createElement("div");
    newDiv.classList.add("boxed");

  // and give it some content
    const newContent = document.createTextNode(filmname);
    const newContent2 = document.createTextNode(time);
    const newContent3 = document.createTextNode(description);
    const linebreak = document.createElement('br');
    const linebreak2 = document.createElement('br');

  // add the text node to the newly created div
    newDiv.appendChild(newContent);
    newDiv.appendChild(linebreak);
    newDiv.appendChild(newContent2);
    newDiv.appendChild(linebreak2);
    newDiv.appendChild(newContent3);

  // add the newly created element and its content into the DOM
    const currentDiv = document.getElementById("black pantherboxed");
    document.body.insertBefore(newDiv, currentDiv);
  }
  
</script>
  <body>
    <center><p1 style="color:red"><font size="+4">Current Films</font></p1><br></center><br> <!--         <br> is a Line break -->
  <form>
        <div id="choice2"style="display:none"><b> Select the movie you would like to remove </b></div>  
        <select id = "myList"style="display:none" onchange = "selectremove()" hidden>  
        <option> black panther </option>  
        <option> devotion </option>  
        <option> strange world </option>  
        <option> ticket to paradise </option>  
        <option> prey for the devil </option>
        <option> rebel moon </option>
        <option> bones and all </option>
        <option> spirited </option>
        </select>  
        <div id="choice" style="display: none">Enter the movie name as it is written above:</div> 
        <p><input type = "text" id = "upcoming" size = "20" style="display:none"></p>
        <button id = "sub1" style = "display:none"onclick= "remove()">Submit</button>
    </form> 
      <form>
          <div id="addchoice" style="display: none">Name of the film you would like to add</div> 
          <p><input type = "text" id = "addchoicetext" size = "20" style="display:none" </p>
          <div id="addchoice2" style="display: none">When does it come to theaters?</div> 
          <p><input type = "text" id = "addchoicetext2" size = "20" style="display:none" </p>
          <div id="addchoice3" style="display: none">Does the movie have a description:</div> 
          <p><input type = "text" id = "addchoicetext3" size = "20" style="display:none" </p>
          <button id = "sub2" style = "display:none"onclick= "addmovie()">Submit</button>
      </form>
    
   
    <div class="boxed" id = "black pantherboxed">
      <img src="bp22.jpg"id = "black pantherimg" alt="Black Panther 2" height = "200"width = "200">
      <br><p  id= "black panthertext"style="font-size:20px">Black Panther: Wakanda Forever</p>
      <a href="https://www.youtube.com/watch?v=_Z3QKkl1WyM&ab_channel=MarvelEntertainment">Trailer</a><br><p id ="black panthertext2">
      Queen Ramonda, Shuri, M'Baku, Okoye and the Dora Milaje fight to protect their nation from         intervening world powers in the wake of King T'Challa's death. As the Wakandans strive to embrace their next chapter, the heroes must band together with Nakia and Everett Ross to forge a new path for their beloved kingdom.<br>Actors: Chadwick Boseman, Tenoch Huerta, Letitia Wright, Michael B. Jordan, Dominique Thorne, Angela Basset, Mabel Cadena, Daniel Kaluuya </p>
<br><br>
      <a href="review.txt" download="Black Panther Reviews">
         Black Panther Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your"><br>
      Movie Name<br><input type ="text"name ="movie"><br>
      <form>
      Review<br><textarea name="textarea"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit"id = "sub1" value="submit"><br>
 
      </div> 
      
      </form>

      </form>
<?php
  $yname=$_GET["your"];
  $mname=$_GET["movie"];
  $comment=$_GET["textarea"];

  $f=fopen("review.txt","a");
  fwrite($f, $mname."\n".$yname." said, " .$comment."\n");
  fclose($f);
?>
      <!-- A button to open the popup form -->
<button class="open-button" onclick="openForm()">Buy a Ticket</button>

<!-- The form -->
<div class="form-popup" id="myForm">
  <form action="currentcat.php" class="form-container" method = "post">
    <h1 style="color:red">See you at the Theater!</h1>
      <label for="location"style="color:black">Choose a theater location:</label><br>
      <select name="location" id="location">
      <option value="Lubbock">Lubbock</option>
      <option value="Amarillo">Amarillo</option>
      <option value="Levelland">Levelland</option>
      <option value="Plainview">Plainview</option>
      <option value="Snyder">Snyder</option>
      <option value="Abilene">Abilene</option>
      </select><br>

       <p style="color:black">What Day will you be Joining us?</p>
      <label for="date"style="color:black">Date:</label>
      <input type="date" id="dmovie" name="dmovie"><br>
    
      <br><label for="movie"style="color:black">Choose a film:</label><br>
      <select name="movie" id="movie">
      <option value="Black Panther: Wakanda Forever">Black Panther: Wakanda Forever</option>
      <option value="Devotion">Devotion</option>
      <option value="Strange World">Strange World</option>
      <option value="Ticket to Paradise">Ticket to Paradise</option>
      <option value="Spirited">Spirited</option>
      <option value="Bones and All">Bones and All</option>
      <option value="Prey for the Devil">Prey for the Devil</option>
      </select><br>
       <p style="color:black">Please Select your Timeslot:</p>
       <label for="timeslot"style="color:black">Timeslot:</label>
      <select name="timeslot" id="time">
      <option value="one">11:00am</option>
      <option value="two">1:30pm</option>
      <option value="three">3:00pm</option>
      <option value="one">5:00pm</option>
      <option value="two">6:30pm</option>
      <option value="three">7:00pm</option>
      <option value="four">8:30pm</option>
      <option value="two">9:00pm</option>
      <option value="three">9:15pm</option>
      <option value="four">9:55pm</option>
      <option value="two">10:30pm</option>
      <option value="three">11:00pm</option>
      <option value="four">12:00am</option>
      </select><br><br>
    
     
  <br><br>
    <input type="submit" value = "submit" >
    <button type="button" onclick="window.location.href='payment.php';">Continue</button>
  <!--<input type="submit" value="Submit" onclick = "window.location.href='payment.php';">-->
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>

<?php
      $amount_ticket=$_GET["numticket"];
      
  
?>    
  
</div>
     

  
  </body> 
        
      

    </div>
    <script>
      function remove(){
        let text1 = "boxed";
        let text2 = document.getElementById("upcoming").value;
        let text3 = "img"
        let text4 = "text";
        let result1 = text2.concat(text1);
        let result2 =text2.concat(text3);
        let result3 = text2.concat(text4);
    
  
    //alert(x);
        var x = document.getElementById(result1).style.display = "none";
        var y = document.getElementById(result2).style.display = "none";
        var z = document.getElementById(result3).style.display = "none";
  
}

</script>
    <div class = "boxed" id = "strange worldboxed">
      <img src ="strange.jpg" id = "strange worldimg"alt ="Strange World" height ="200"width = "200">
      <br><p  id= "strange worldtext"style="font-size:20px">Strange World</p>
      <a href="https://www.youtube.com/watch?v=bKh2G73gCCs&ab_channel=WaltDisneyAnimationStudios">Trailer</a><br>
     <p id ="strange worldtext2" The Clades are a legendary family of explorers whose differences threaten to topple their          latest and most crucial mission into uncharted and treacherous territory.<Br>Actors: Jake Gyllenhaal, Jaboukie Young-White, Gabriel Union, Dennis Quaid, Lucy Liu /p>
    
    <br>
       <a href="review1.txt" download="Strange World Reviews">
         Strange World Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your1"><br>
      Movie Name<br><input type ="text"name ="movie1"><br>
      <form>
      Review<br><textarea name="textarea1"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your1"];
  $mname=$_GET["movie1"];
  $comment=$_GET["textarea1"];

  $f=fopen("review1.txt","a");
  fwrite($f, $mname."\n".$yname."\n " .$comment."\n");
  fclose($f);
?>
  </div>
  </body> 

    <div class = "boxed" id = "devotionboxed">
      <img src ="devotion.jpg" id = "devotionimg"alt ="Devotion" height ="200"width = "200">
      <br><p  id= "devotiontext"style="font-size:20px">Devotion</p>
      <a href="https://www.youtube.com/watch?v=nIvBBd8pU1s&ab_channel=SonyPicturesEntertainment">Trailer</a><br>
     <p id ="devotiontext2" The inspirational true story of Jesse Brown, the first Black aviator in U.S. Navy history,         and his enduring friendship with fellow fighter pilot Tom Hudner. Helping to turn the tide         in the most brutal battle in the Korean War, their heroic sacrifices ultimately make them          the Navy's most celebrated wingmen.<br>Actors: Glen Powell, Jonathon Majors, Daren Kagasoff, Joe Jonas, Serinda Swan, Nick Hargrove, Spencer Neville, Emily Brinks /p>
    <br><br>
      <a href="review2.txt" download="Devotion Reviews">
         Devotion Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your2"><br>
      Movie Name<br><input type ="text"name ="movie2"><br>
      <form>
      Review<br><textarea name="textarea2"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your2"];
  $mname=$_GET["movie2"];
  $comment=$_GET["textarea2"];

  $f=fopen("review2.txt","a");
  fwrite($f, $mname."\n".$yname."\n " .$comment."\n");
  fclose($f);
?>
    </div>

    <div class = "boxed"id = "ticket to paradiseboxed">
      <img src ="ticket.jpg"id = "ticket to paradiseimg" alt ="Ticket to Paradise" height ="200"width = "200">
      <br><p  id= "ticket to paradisetext"style="font-size:20px">Ticket to Paradise</p>
      <a href="https://www.youtube.com/watch?v=hkP4tVTdsz8&ab_channel=UniversalPictures">Trailer</a><br>
     <p id ="tickets to paradisetext2"> A man and his ex-wife race to Bali, Indonesia, to stop their daughter from marrying a seaweed farmer. As they desperately try to sabotage the wedding, the bickering duo soon find themselves rekindling old feelings that once made them happy together.<br>Actors: Julia Roberts. George Clooney, Kaitlyn Dever, Maxime Bouttier, Lucas Bravo, Billie Lourd, Romy Poulier, Rowan Chapman </p>
      <br><br>
      <a href="review3.txt" download="Ticket to Paradise Reviews">
         Ticket to Paradise Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your3"><br>
      Movie Name<br><input type ="text"name ="movie3"><br>
      <form>
      Review<br><textarea name="textarea3"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your3"];
  $mname=$_GET["movie3"];
  $comment=$_GET["textarea3"];

  $f=fopen("review3.txt","a");
  fwrite($f, $mname."\n".$yname." said, " .$comment."\n");
  fclose($f);
?>
  
    </div>

    <div class = "boxed"id = "prey for the devilboxed">
      <img src ="prey.jpg"id = "prey for the devilimg" alt ="Prey for the Devil" height ="200"width = "200">
      <br><p  id= "prey for the deviltext"style="font-size:20px">Prey for the Devil</p>
      <a href="https://www.youtube.com/watch?v=OkEnG6inG4c&ab_channel=LionsgateMovies">Trailer</a><br>
      <p id ="prey for the deviltext2">The Roman Catholic Church combats a global rise in demonic possessions by reopening schools to train priests to perform exorcisms. Although nuns are forbidden to perform this ritual, a professor recognizes Sister Ann's gifts and agrees to train her. Thrust onto the spiritual frontline, she soon finds herself in a battle for the soul of a young girl who's possessed by the same demon that tormented her own mother years earlier.<br>Actors: Jacqueline Byers, Christian Navarro, Colin Salmon, Nicholas Ralph, Ben Cross, Virginia Madsen, Tom Forbes, Debora, Zheceva </p>
      <br><br>
      <a href="review4.txt" download="Prey for the Devil Reviews">
         Prey for the Devil Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your4"><br>
      Movie Name<br><input type ="text"name ="movie4"><br>
      <form>
      Review<br><textarea name="textarea4"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your4"];
  $mname=$_GET["movie4"];
  $comment=$_GET["textarea4"];

  $f=fopen("review4.txt","a");
  fwrite($f, $mname."\n".$yname."\n " .$comment."\n");
  fclose($f);
?>
  
    </div>

    <div class = "boxed"id = "spiritedboxed">
      <img src ="spirited.jpg" id = "spiritedimg"alt ="Spirited" height ="200"width = "200">
      <br><p  id= "spiritedtext"style="font-size:20px">Spirited</p>
      <a href="https://www.youtube.com/watch?v=Tq6mXhFZIlU&ab_channel=RottenTomatoesTrailers">Trailer</a><br>
      A musical version of Charles Dickens' story of a miserly misanthrope who's taken on a magical journey.
      <br>Actors: Ryan Reynolds,Will Ferrel, Sunita Mani, Tracy Morgan, Octavia Spencer, Patrick Page, Marlow
      Barklry, Rose Byrne 
      <br><br>
      <a href="review5.txt" download="Spirited Reviews">
         Spirited Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your5"><br>
      Movie Name<br><input type ="text"name ="movie5"><br>
      <form>
      Review<br><textarea name="textarea5"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your5"];
  $mname=$_GET["movie5"];
  $comment=$_GET["textarea5"];

  $f=fopen("review5.txt","a");
  fwrite($f, $mname."\n".$yname."\n " .$comment."\n");
  fclose($f);
?>
  
    </div>

    <div class = "boxed"id = "bones and allboxed">
      <img src ="bones.jpg"id = "bones and allimg" alt ="Bones and All" height ="200"width = "200">
      <br><p  id= "bones and alltext"style="font-size:20px">Bones and All</p>
      <a href="https://www.youtube.com/watch?v=0Nu7Z9AxGNg&ab_channel=MGM">Trailer</a><br>
      <p id ="bones and alltext2">Love blossoms between a young woman on the margins of society and a disenfranchised drifter as they
      embark on a 3,000-mile odyssey through the backroads of America. However, despite their best efforts,
      all roads lead back to their terrifying pasts and a final stand that will determine whether their love
      can survive their differences.<br>Actors: Timoth&eacutee Chalamet, Taylor Russell, Mark Rylance,
      Chlo&euml Sevigny, Michael Stuhlburg, Madeleine Hall, Anna Cobb, Jessica Harper</p>
      <br><br>
      <a href="review6.txt" download="Bones and All Reviews">
         Bones and All Reviews<br>
      </a>
      Seen this movie? Leave a review Here!<br>
     <body>
      <form action="currentcat.php" method = "get">
     
      Your name<br><input type ="text"name ="your6"><br>
      Movie Name<br><input type ="text"name ="movie6"><br>
      <form>
      Review<br><textarea name="textarea6"rows="5" cols="33"></textarea>

      <br><div>
    
      <input type="submit" value="submit"><br>
 
      </div> 
      </form>
  
     
</form>
<?php
  $yname=$_GET["your6"];
  $mname=$_GET["movie6"];
  $comment=$_GET["textarea6"];

  $f=fopen("review6.txt","a");
  fwrite($f, $mname."\n".$yname."\n " .$comment."\n");
  fclose($f);
?>
  
    </div>
   <!--</form>-->
  </body>
</html>
<script src="script.js"></script>
