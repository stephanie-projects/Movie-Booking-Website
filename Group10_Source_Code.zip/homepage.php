<html>
  <head>
    <title>Homepage</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center>
  <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Log Out</button>
</div>
</div>

<body>
  <p1>Welcome!</p1><br> <!-- <br> is a Line break -->

<label for="site-search">Search the site:</label>
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for films...">

<table id="myTable">
  <tr class="header">
    <th style="width:60%;">Movie Title</th>
    <th style="width:40%;">Current/Upcoming Films</th>
  </tr>
  <tr>
    <td>Barbie</td>
    <td>Upcoming</td>
  </tr>
  <tr>
    <td>Black Panther: Wakanda Forever</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Bones and All</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Devotion</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>M3gan</td>
    <td>Upcoming</td>
  </tr>
  <tr>
    <td>Peter Pan and Wendy</td>
    <td>Upcoming</td>
  </tr>
  <tr>
    <td>Prey for the Devil</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Rebel Moon</td>
    <td>Upcoming</td>
  </tr>
  <tr>
    <td>Shreck 5</td>
    <td>Upcoming</td>
  </tr>
  <tr>
    <td>Spirited</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Strange World</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Ticket to Paradise</td>
    <td>Current</td>
  </tr>
  <tr>
    <td>Wonka</td>
    <td>Upcoming</td>
  </tr>
</table>
  
<center>
<button class="button button4"
  onclick= "window.location.href='upcoming.php';">Upcoming</button>
<button class = "button button5"
  onclick = "window.location.href='currentcat.php';">Current</button>
  <br><br>
<marquee  behavior="scroll" direction="left">        
          <img src= "soul.jpg">
          <img src= "harry.jpg">
          <img src= "batman.jpg">
          <img src= "bp2.jpg">
          <img src= "lightyear.jpg">
          <img src= "ambulance.jpg">
          <img src= "avatar2.jpg">
          <img src= "dunkirk.jpg">
          <img src= "uncharted.jpg">
          <img src= "hp2.jpg">
          <img src= "topgun.jpg">
          <img src= "nope.jpg">
          <img src= "elvis.jpg">
  
          
    </marquee>
  </body>

</html>
<script src="script.js"></script>