<?php
session_start();
?>
<html>
  <head>
    <title>Upcoming Films</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center>
  <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Log Out</button>
  <button class="btn_right"
  onclick= "window.location.href='homepage.php';">Homepage</button>
</div>
</div>

<?php
if($_SESSION["admin"] == "loggedin"){
  print_r("Welcome admin, Let's begin<br>");
  //echo "<button onClick='start()'>Start</button>";
  //show_hide() function is triggered on button click 
  echo "<button onClick='selectremove()'>Remove Films</button>";
  echo "<button onClick='add()'>Add Films</button>";
    
}
?>
<script>
  function selectremove() {
  var x = document.getElementById("choice");
  var y = document.getElementById("myList");
  var z = document.getElementById("upcoming");
  var a = document.getElementById("choice2");
  var b = document.getElementById("sub1");
  if (x.style.display == 'none') {
    x.style.display = "block";
    y.style.display = "block";
    z.style.display = "block";
    a.style.display = "block";
    b.style.display = "block";
  }
  
}
</script>
  
<script>
  function add() {
  var x = document.getElementById("addchoice");
  var y = document.getElementById("addchoicetext");
  var z = document.getElementById("addchoice2");
  var a = document.getElementById("addchoicetext2");
  var b = document.getElementById("addchoice3");
  var c = document.getElementById("addchoicetext3");
  var d = document.getElementById("sub2");
  if (x.style.display == 'none') {
    x.style.display = "block";
    y.style.display = "block";
    z.style.display = "block";
    a.style.display = "block";
    b.style.display = "block";
    c.style.display = "block";
    d.style.display = "block";
  }
  }
</script>
<script>
  function addmovie() {
    var filmname = document.getElementById("addchoicetext").value;
    var time = document.getElementById("addchoicetext2").value;
    var description = document.getElementById("addchoicetext3").value;
    const newDiv = document.createElement("div");
    newDiv.classList.add("boxed");

  // and give it some content
    const newContent = document.createTextNode(filmname);
    const newContent2 = document.createTextNode(time);
    const newContent3 = document.createTextNode(description);

  // add the text node to the newly created div
    newDiv.appendChild(newContent);
    newDiv.appendChild(newContent2);
    newDiv.appendChild(newContent3);

  // add the newly created element and its content into the DOM
    const currentDiv = document.getElementById("shreckboxed");
    document.body.insertBefore(newDiv, currentDiv);
  }
  
</script>
  <body>
    <center><p1 style="color:red"><font size="+4">Upcoming Films</font></p1><br></center><br> <!-- <br> is a Line break -->
        <form>
        <div id="choice2"style="display:none"><b> Select the movie you would like to remove </b></div>  
        <select id = "myList"style="display:none" onchange = "selectremove()" hidden>  
        <option> shreck </option>  
        <option> wonka </option>  
        <option> m3gan </option>  
        <option> barbie </option>  
        <option> peter pan and wendy </option>
        <option> rebel moon </option>
        </select>  
        <div id="choice" style="display: none">Enter the movie name as it is written above:</div> 
        <p><input type = "text" id = "upcoming" size = "20" style="display:none"></p>
        <button id = "sub1" style = "display:none"onclick= "remove()">Submit</button>
    </form> 
      <form>
          <div id="addchoice" style="display: none">Name of the film you would like to add</div> 
          <p><input type = "text" id = "addchoicetext" size = "20" style="display:none" </p>
          <div id="addchoice2" style="display: none">When does it come to theaters?</div> 
          <p><input type = "text" id = "addchoicetext2" size = "20" style="display:none" </p>
          <div id="addchoice3" style="display: none">Does the movie have a description:</div> 
          <p><input type = "text" id = "addchoicetext3" size = "20" style="display:none" </p>
          <button id = "sub2" style = "display:none"onclick= "addmovie()">Submit</button>
      </form>

    <div class="boxed" id = "shreckboxed">
      <img src="shreck5.jpg" id = "shreckimg" alt="Shreck 5" height = "200"width = "200">
    <br><p  id= "shrecktext"style="font-size:20px">Shreck 5<br>Coming to Theaters May 2023</p>
    </div>
<script>
  function remove(){
    let text1 = "boxed";
    let text2 = document.getElementById("upcoming").value;
    let text3 = "img"
    let text4 = "text";
    let result1 = text2.concat(text1);
    let result2 =text2.concat(text3);
    let result3 = text2.concat(text4);
    
  
    //alert(x);
    var x = document.getElementById(result1).style.display = "none";
    var y = document.getElementById(result2).style.display = "none";
    var z = document.getElementById(result3).style.display = "none";
    //document.getElementById("shreckimg").hidden = true;
    
    sessionStorage.setItem('x', 'true');
    //localStorage.setItem('item', 'x');
    window.onload=onload();

//and to retrieve and if not exist return firstDiv
    function onload(){
      if(sessionStorage.getItem('x') == 'true') {
        document.getElementById("shreckimg").hidden = true;
        document.getElementById(result2).style.display = "none";
      } 
    }
  
}

</script>

    <div class="boxed" id = "wonkaboxed">
      <img src="wonka.jpg"id = "wonkaimg" alt="Wonka"height = "200"width = "200">
    <br><p  id= "wonkatext"style="font-size:20px">Wonka<br>Coming to Theaters Dec 2023</p>
    </div>

    <div class="boxed" id = "barbieboxed">
      <img src="barbie.jpg"id = "barbieimg" alt="Barbie""200"width = "200">
    <br><p  id= "barbietext"style="font-size:20px">Barbie<br>Coming to Theaters July 2023</p>
    </div>

    <div class="boxed" id = "peter pan and wendyboxed">
      <img src="ppw.jpg"id = "peter pan and wendyimg" alt="Peter Pan and Wendy"height = "200"width = "200">
    <br><p  id= "peter pan and wendytext"style="font-size:20px">Peter Pan and Wendy<br>Coming soon to THeaters</p>
    </div>

    <div class="boxed" id = "m3ganboxed">
      <img src="m3gan.jpg" id = "m3ganimg" alt="M3GAN"height = "200"width = "200">
    <br><p  id= "m3gantext"style="font-size:20px">M3gan<br>Coming to Theaters January 2023</p>
      <a href="https://www.youtube.com/watch?v=BRb4U99OU80&ab_channel=UniversalPictures">Trailer</a><br>
      M3GAN is a marvel of artificial intelligence, a lifelike doll that's programmed to be a            child's greatest companion and a parent's greatest ally. Designed by Gemma, a brilliant            roboticist, M3GAN can listen, watch and learn as it plays the role of friend and teacher,          playmate and protector. When Gemma becomes the unexpected caretaker of her 8-year-old niece,       she decides to give the girl an M3GAN prototype, a decision that leads to unimaginable             consequences.
    </div>
      <div class="boxed" id = "rebel moonboxed">
      <img src="rebel.jpg" id = "rebel moonimg"alt="Rebel Moon"height = "200"width = "200">
    <br><p  id= "rebel moontext"style="font-size:20px">Rebel Moon<br>Coming soon to Theaters</p>
       <br> A young woman seeks out warriors from other planets to fight the tyrannical armies terrorizing her peaceful colony.
    </div>
    
    
  </body>
</html>
<script src="script.js"></script>