<html>
  <head>
    <title>Administrator</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Admin Tech Theaters</center></h1>
  <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Log Out</button>
</div>
</div>

<body>
  <p1>Welcome Admin!</p1><br> <!-- <br> is a Line break -->
  <p1>Remove item from Upcoming Movies</p1><br>
    <br><label for="movie"style="color:black">Choose a film:</label><br>
      <select name="movie" id="upcoming">
      <option value="shreck">Shreck 5</option>
      <option value="wonka">Wonka</option>
      <option value="barbie">Barbie</option>
      <option value="m3gan">M3gan</option>
      <option value="peter pan and wendy">Peter Pan and Wendy</option>
      <option value="rebel moon">Rebel Moon</option>
      </select><br>
    <button onclick="upcoming(document.getElementById('upcoming').value)">Remove</button>
  <p1>Remove item from Current Movies</p1><br>
  <br><label for="movie"style="color:black">Choose a film:</label><br>
      <select name="movie" id="current">
      <option value="Black Panther: Wakanda Forever">Black Panther: Wakanda Forever</option>
      <option value="Devotion">Devotion</option>
      <option value="Strange World">Strange World</option>
      <option value="Ticket to Paradise">Ticket to Paradise</option>
      <option value="Spirited">Spirited</option>
      <option value="Bones and All">Bones and All</option>
      <option value="Prey for the Devil">Prey for the Devil</option>
      </select><br>
  <button onclick="current(document.getElementById('current').value)">Remove</button>
  <p1>Overall Status</p1><br>
 

 
    


  </body>

</html>
<script src="script.js"></script>