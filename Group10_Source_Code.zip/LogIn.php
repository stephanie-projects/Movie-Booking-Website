<?php
session_start();
?>
<?php

    $username = $_GET['username'];
    $password = $_GET['password'];
    $f=fopen("validation.txt","a");
    fwrite($f, "Username: " .$username." Password: ".$password. "\n");
    fclose($f);
    
    $wow = file_get_contents("info.txt");
    $bow = file_get_contents("validation.txt");

    if($username == "techtheaters@ttu.edu" && $password == "tech"){
      $_SESSION["admin"] = "loggedin";
      header('Location: homepage.php');
      //$admin = TRUE;
      //echo '<script>admin();</script>';
      //header('Location: admin.php');
exit();
    }
    if(strpos($wow, $username) != 0){
      if(strpos($wow, $password) != 0){
        $_SESSION["admin"] = "loggedout";
        header('Location: homepage.php');
exit();
      }
    }
    
?>
<html>
<head>
    <title>LogIn Test</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  <script src="script.js"></script>
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  
  <!--class = "box"-->
<body>
  <div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center>
    <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Return</button>
</div>
</div>
  <form action = "LogIn.php" method = "get">
    <center><h1>Login</h1>
    Username/email:<br><input type ="text"name ="username"><br>
    Password:<br><input type ="text"name ="password"><br>
    <!--<input type = "text" name ="" placeholder = "Enter email" name = "username">
    <input type = "password" name ="" placeholder = "Enter password" name = "password">-->
    <!--<input type = "submit" value = "Login" name = "Login">-->
    <input type="submit" value="submit"><br>
  </form>


</body>



  
</html>