<?php
session_start();
?>
<html>
  <head>
    <title>PHP Test</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center>
  <div class="btn_right">
  <button class="btn_right"
  onclick= "window.location.href='index.php';">Log Out</button>
  <button class="btn_right"
  onclick= "window.location.href='homepage.php';">Homepage</button>
  <button class="btn_right"
  onclick= "window.location.href='currentcat.php';">Current Films</button>
</div>
</div>

<?php
if($_SESSION["admin"] == "loggedin"){
  print_r("Welcome admin, Let's begin<br>");
 // echo "<button onClick='start()'>Start</button>";
  //show_hide() function is triggered on button click 
  echo "The total amount of tickets sold is: " . $_SESSION["total"];
  //echo "<button onClick='status()'>See Ticket Status</button>";
}
?>

 
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="payment.php">
           <div class="col-25">
    <div class="container">
      <h4>Cart
        <span class="price" style="color:white">
          <i class="fa fa-shopping-cart"></i>
          <br><br>
    
      <label for="numticket"style="color:white">Number of Tickets:($15 per ticket)</label><br>
      <select name="numticket" id="ticket">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
      <option value="8">8</option>
      <option value="9">9</option>
      <option value="10">10</option>
      </select><br>
      </span></h4>
        <?php
        $ticket = $_GET['numticket'];
        $ticket2 = $_GET['numticket'];
        //$finalsales +=$ticket;
        $_SESSION["total"] +=$ticket2;
        $price =15;
        $total = ($price * $ticket);
        echo("<br>You bought ");
        echo $ticket;
        echo(" tickets. ");
        echo("Your total is $");
        echo $total;
        echo(" dollars.");
        echo("<br>Your confirmation code is: ");
        echo uniqid(); //generates random value based on the timestamp, will be confrimation/ qr code
      ?>     
    </div>
  </div>
</div>
  
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe">
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="john@example.com">
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="ex)542 W. 15th Street">
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="ex)New York">

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="NY">
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="10001">
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-paypal" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe">
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September">

            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352">
              </div>
            </div>
          </div>

        </div>
        
        <input type="submit" value="Continue to checkout" class="btn">
      </form>
      
    </div>
  </div>

 
</html>
<script src="script.js"></script>