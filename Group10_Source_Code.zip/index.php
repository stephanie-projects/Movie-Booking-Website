<html>
  <head>
    <title>PHP Test</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
  <center>Lubbock&#183;Amarillo&#183;Levelland&#183;Plainview&#183;Snyder&#183;Abilene</center></p>
</div>

<body>
  <p1>Welcome!</p1><br> <!-- <br> is a Line break -->
  <p2>Are you a new or returning user?</p2><br>

  <center>
<button class="button button1"
  onclick= "window.location.href='newUser.php';">New User</button>
<button class="button button2"
  onclick="window.location.href='LogIn.php';">Returning User</button>
    


  </body>

</html>
<script src="script.js"></script>