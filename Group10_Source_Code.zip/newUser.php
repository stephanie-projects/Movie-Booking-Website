<html>
  <head>
    <title>NewUser Test</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script src="script.js"></script>
  </head>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
<div class="header2">
  <h1><center>Tech Theaters</center></h1>
</div>
  <p1>Want to sign up and get all of Tech Theater's perks!</p1><br><br> <!-- <br> is a Line break -->
  <right>
  <button class="button button3"
      onclick="window.location.href='index.php';">Return</button><br>
<body>
<form action="newUser.php" method = "get">
  <center>
  Firstname:<br><input type ="text"name ="first"><br>
  Lastname:<br><input type ="text"name ="last"><br>
  Email Address:<br><input type ="text"name ="email"><br>
  Home Address:<br><input type ="text"name ="home"><br>
  Phone Number:<br><input type ="text"name ="phone"><br>
  Password:<br><input type ="text"name ="pass"><br>
  
  <br><div>
    
  <input type="submit" value="submit"><br>
 
  </div>    
</form>
<?php
  $first=$_GET["first"];
  $last=$_GET["last"];
  $email=$_GET["email"];
  $home=$_GET["home"];
  $phone=$_GET["phone"];
  $pass=$_GET["pass"];
  $f=fopen("info.txt","a");
  fwrite($f, "Firstname: " .$first." Lastname: ".$last." Email Address: " .$email." Home Address: ".$home." Phone Number: ".$phone." Password: ".$pass. "\n");
  fclose($f);
?>
  </body>

</html>